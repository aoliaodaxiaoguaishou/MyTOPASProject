// The example class categories definitions for Doxygen

/// \file Doxymodules_polarisation.h
/// \brief The page that defines the extended/polarisation examples modules 


/** @defgroup extended_polarisation polarisation
 *  Extended examples eventgenerator classes
 *  @{
 */

/** @defgroup extended_polarisation_Pol01 Pol01
 *  polarisation Pol01 example has its
 *  <a href="../html_Pol01/html/index.html">standalone documentation </a>
 *  @ingroup extended_polarisation
 *  @{
 */

/** @} */

/** @} */
